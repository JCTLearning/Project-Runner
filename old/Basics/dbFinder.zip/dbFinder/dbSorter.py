import json
import os
import glob

 
class main:
	def __init__(self):
		print('Started main program -- DB check')
	def buildJson(self):
		
		with open("dbfiles.json", "w") as self.dbFile:
			json.dump({'dbFiles':'3', '1':'team1.txt', '2':'team2.txt', '3':'team3.txt'}, self.dbFile, indent=4)
		
		"""
		What I wanna do here is create a loop that dumps the list of .db files into a json format... I suppose we don't have to do it this way
			for file in glob.glob("*.db"):
				self.dbList1.insert(self.x, file)
		We could use this part ^ in order to list the db files in a dir and assign them to a list, then when we need them we can call them via list id...
		Or instead of that we can create another sql file that displays all the db files...
		so we have 3 options
		1.) Figure out a way to create a file that holds all the db file names (like a dictionary)
			// For this maybe we could just create a file that holds the dictionary, and we can call back to that instead of creating a entire dictionary everytime, basically just store the created list on disk in a ".txt"
		2.) Just find all files in one dir with a .db extention, pack them in a list, and call when needed
		3.) Create a Db file that shows all the other db files.
		self.x = 1
		self.dbList1 = []
		with open("dbfiles.json", "w") as self.dbFile:
			for file in glob.glob("*.db"):
				self.dbList1.insert(self.x, file)
				self.x = self.x + 1
			self.indexE = self.x + 1
			self.dbList1.insert(self.indexE, 'null') #stops the sys from throwing a rightmost index boundary error
			self.dbList1.insert(0,self.x-1)
			self.y = 1
			self.numberOfDb = self.dbList1[0]
			self.numberOfDbMax = self.x + 1

			while(self.y!=self.numberOfDbMax):
				self.dbFileName = self.dbList1[self.y]
				json.dump({self.y:self.dbFileName}, self.dbFile, indent = 4)
				self.y = self.y + 1
			    
			json.dump({'dbFiles':self.numberOfDb}, self.dbFile, indent = 4)
                        """ 
		print('Test data base files added to json...')
		print('Executing data base sort and input...')
		self.buildDb()
	def buildDb(self):
		with open("dbfiles.json", "r") as self.dbFile:
			self.dbData = json.load(self.dbFile)
			self.numberOfDb = int(self.dbData["dbFiles"])
			self.numberOfDb = self.numberOfDb + 1 #Doing this so I can grab all the teams
			self.x = 1
			global dbList
			dbList = []
			while(self.x!=self.numberOfDb):
				self.listNum = self.x-1
				self.teamId = str(self.x)
				self.dbInsert = self.dbData[self.teamId]
				dbList.insert(self.listNum, self.dbInsert)
				self.x = self.x + 1				
			print('Done inserting values into the list. The avalible Db files are...'),
			print(dbList)
			"""
			From here we can ask the user if he wants team 1, 2, or 3. Then use list id to select that as current teams
			"""
mainC = main()
mainC.buildJson()
